import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import AdminNavbar from "@/components/AdminNavbar";
import ProtectedAdminRoute from "@/components/ProtectedAdminRoute";
import AdminCharts from "@/components/AdminCharts";
import AdminTopCircles from "@/components/AdminTopCircles";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Users, 
  UserCheck, 
  BookOpen, 
  TrendingUp, 
  FileText, 
  Award, 
  ClipboardList,
  Settings
  ,Gift
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface AdminPage {
  title: string;
  description: string;
  icon: LucideIcon;
  path: string;
  color: string;
  bgGradient: string;
}

const AdminDashboard = () => {
  const [totalStudents, setTotalStudents] = useState<number>(0);
  const [totalTeachers, setTotalTeachers] = useState<number>(0);
  const [totalCircles, setTotalCircles] = useState<number>(0);
  const [attendanceRate, setAttendanceRate] = useState<string>("0%");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);

      // جلب عدد الطلاب
      const { count: studentsCount, error: studentsError } = await supabase
        .from('students')
        .select('*', { count: 'exact', head: true });

      if (studentsError) throw studentsError;
      setTotalStudents(studentsCount || 0);

      // جلب عدد الأساتذة
      const { count: teachersCount, error: teachersError } = await supabase
        .from('teachers')
        .select('*', { count: 'exact', head: true });

      if (teachersError) throw teachersError;
      setTotalTeachers(teachersCount || 0);

      // جلب عدد الحلقات
      const { count: circlesCount, error: circlesError } = await supabase
        .from('circles')
        .select('*', { count: 'exact', head: true });

      if (circlesError) throw circlesError;
      setTotalCircles(circlesCount || 0);

      // حساب معدل الحضور اليومي
      const today = new Date().toISOString().split('T')[0];
      
      // جلب عدد الطلاب الحاضرين اليوم
      const { count: presentCount, error: presentError } = await supabase
        .from('student_attendance')
        .select('*', { count: 'exact', head: true })
        .eq('date', today)
        .eq('status', 'present');

      if (presentError) throw presentError;

      // حساب النسبة
      if (studentsCount && studentsCount > 0) {
        const rate = ((presentCount || 0) / studentsCount) * 100;
        setAttendanceRate(`${Math.round(rate)}%`);
      } else {
        setAttendanceRate("0%");
      }

    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const stats = [
    {
      title: "إجمالي الطلاب",
      value: loading ? "..." : totalStudents.toString(),
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: "عدد الأساتذة",
      value: loading ? "..." : totalTeachers.toString(),
      icon: UserCheck,
      color: "text-emerald-600",
      bgColor: "bg-emerald-50",
    },
    {
      title: "عدد الحلقات",
      value: loading ? "..." : totalCircles.toString(),
      icon: BookOpen,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
    {
      title: "معدل الحضور اليومي",
      value: loading ? "..." : attendanceRate,
      icon: TrendingUp,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
    },
  ];

  const adminPages: AdminPage[] = [
    {
      title: "إدارة الطلاب",
      description: "عرض وإدارة جميع الطلاب في المعهد",
      icon: Users,
      path: "/admin/students",
      color: "text-blue-600",
      bgGradient: "from-blue-500/10 to-blue-600/10"
    },
    {
      title: "إدارة الأساتذة",
      description: "إدارة حسابات الأساتذة والصلاحيات",
      icon: UserCheck,
      path: "/admin/teachers",
      color: "text-green-600",
      bgGradient: "from-green-500/10 to-green-600/10"
    },
    {
      title: "إدارة الحلقات",
      description: "إنشاء وتعديل الحلقات الدراسية",
      icon: BookOpen,
      path: "/admin/circles",
      color: "text-purple-600",
      bgGradient: "from-purple-500/10 to-purple-600/10"
    },
    {
      title: "سجلات الطلاب",
      description: "عرض السجلات والمحصلات الأسبوعية والشهرية",
      icon: FileText,
      path: "/admin/records",
      color: "text-orange-600",
      bgGradient: "from-orange-500/10 to-orange-600/10"
    },
    {
      title: "سجلات الاختبارات",
      description: "عرض وإدارة جميع اختبارات الطلاب",
      icon: ClipboardList,
      path: "/admin/exam-records",
      color: "text-red-600",
      bgGradient: "from-red-500/10 to-red-600/10"
    },
    {
      title: "سجلات النقاط",
      description: "عرض نقاط الحماس والترتيب",
      icon: Award,
      path: "/admin/points-records",
      color: "text-indigo-600",
      bgGradient: "from-indigo-500/10 to-indigo-600/10"
    },
    {
      title: "إدارة النقاط",
      description: "إضافة وتعديل نقاط الطلاب",
      icon: Award,
      path: "/admin/points",
      color: "text-yellow-600",
      bgGradient: "from-yellow-500/10 to-yellow-600/10"
    },
    {
      title: "سجل الغياب",
      description: "عرض وإدارة غيابات الطلاب",
      icon: UserCheck,
      path: "/admin/attendance",
      color: "text-cyan-600",
      bgGradient: "from-cyan-500/10 to-cyan-600/10"
    },
    {
      title: "وضع الصيانة",
      description: "تفعيل وإيقاف وضع الصيانة للنظام",
      icon: Settings,
      path: "/admin/maintenance",
      color: "text-gray-600",
      bgGradient: "from-gray-500/10 to-gray-600/10"
    },
    {
      title: "الطلاب المنقطعين",
      description: "عرض وإدارة الطلاب المنقطعين",
      icon: Users,
      path: "/admin/discontinued-students",
      color: "text-red-600",
      bgGradient: "from-red-500/10 to-red-600/10"
    },
    {
      title: "المحصلات الشهرية",
      description: "رفع صور المحصلات الشهرية للحلقات",
      icon: FileText,
      path: "/admin/monthly-summary",
      color: "text-teal-600",
      bgGradient: "from-teal-500/10 to-teal-600/10"
    },
    {
      title: "إدارة الهدايا",
      description: "إضافة هدايا وأسعارها وصورها للطلاب",
      icon: Gift,
      path: "/admin/gifts",
      color: "text-amber-600",
      bgGradient: "from-amber-500/10 to-orange-600/10"
    }
  ];

  const handlePageClick = (path: string) => {
    navigate(path);
  };

  return (
    <ProtectedAdminRoute>
      <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background islamic-pattern">
        <AdminNavbar />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header Section */}
          <div className="mb-8 fade-in-up">
            <div className="islamic-card p-8 mb-8">
              <h2 className="text-4xl font-bold text-primary text-right mb-2">
                مرحباً بك في لوحة تحكم المدير
              </h2>
              <p className="text-xl text-muted-foreground text-right">
                إدارة شاملة لمعهد القرآن الكريم
              </p>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card 
                  key={stat.title} 
                  className={`islamic-card hover:shadow-xl transition-all duration-300 ${
                    index % 2 === 0 ? 'fade-in-up' : 'fade-in-right'
                  }`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="text-right">
                        <p className="text-sm font-medium text-muted-foreground">
                          {stat.title}
                        </p>
                        <p className="text-3xl font-bold text-foreground mt-2">
                          {stat.value}
                        </p>
                      </div>
                      <div className={`p-3 rounded-full ${stat.bgColor}`}>
                        <Icon className={`w-6 h-6 ${stat.color}`} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Charts Section */}
          <AdminCharts />

          {/* Top Circles Section */}
          <AdminTopCircles />
        </div>
      </div>
    </ProtectedAdminRoute>
  );
};

export default AdminDashboard;
